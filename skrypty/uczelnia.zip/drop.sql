SET client_encoding='utf-8';

DROP TABLE jest_sluchaczem CASCADE;
DROP TABLE termin CASCADE;
DROP TABLE przedmiot CASCADE;
DROP TABLE student CASCADE;
DROP TABLE nauczyciel CASCADE;
